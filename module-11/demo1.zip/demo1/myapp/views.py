from django.shortcuts import render, HttpResponse

# Create your views here.
def home(request):
    return HttpResponse("Masoner Says Hello!")
from django.http import HttpResponse 

